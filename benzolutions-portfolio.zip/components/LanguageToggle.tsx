'use client';
import { useState, useEffect } from 'react';

type Lang = 'nl' | 'en';

export default function LanguageToggle({ onChange }: { onChange: (lang: Lang) => void }) {
  const [lang, setLang] = useState<Lang>('nl');

  useEffect(() => {
    onChange(lang);
    document.documentElement.lang = lang;
  }, [lang, onChange]);

  return (
    <div className="inline-flex items-center gap-2 rounded-full border border-gray-700 bg-neutral-900 p-1">
      <button
        onClick={() => setLang('nl')}
        className={`px-3 py-1.5 text-sm rounded-full ${lang === 'nl' ? 'bg-cyan-500 text-black' : 'text-gray-300 hover:text-white'}`}
        aria-pressed={lang === 'nl'}
      >
        NL
      </button>
      <button
        onClick={() => setLang('en')}
        className={`px-3 py-1.5 text-sm rounded-full ${lang === 'en' ? 'bg-cyan-500 text-black' : 'text-gray-300 hover:text-white'}`}
        aria-pressed={lang === 'en'}
      >
        EN
      </button>
    </div>
  );
}

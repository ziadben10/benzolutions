'use client';
import { useState, useRef, useEffect } from 'react';

type Message = { role: 'user' | 'bot', text: string };

const canned = [
  { k: /prijs|kosten|cost/i, v: 'Prijzen zijn projectafhankelijk. Voor eenvoudige chatbots start het vanaf €99 voor setup + optioneel onderhoud per maand.'},
  { k: /zoho|creator/i, v: 'Ik bouw in Zoho Creator: formulieren, workflows, en koppelingen met CRM of mail. Ook AI-koppelingen zijn mogelijk.'},
  { k: /afspraak|contact/i, v: 'Je kunt contact opnemen via het formulier onderaan of WhatsApp. Ik reageer normaal dezelfde dag.'},
  { k: /chatbot/i, v: 'Ik maak website-, WhatsApp- en AI-gedreven chatbots. We kiezen wat past bij jouw bedrijf.'},
];

function replyTo(input: string) {
  const m = canned.find(c => c.k.test(input));
  return m?.v ?? 'Dit is een demo. Stel gerust een vraag over chatbots, Zoho of automatisering.';
}

export default function ChatbotDemo() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'bot', text: 'Welkom bij de BenZolutions demo. Waar kan ik mee helpen?' }
  ]);
  const [input, setInput] = useState('');
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, open]);

  function send() {
    const q = input.trim();
    if (!q) return;
    setMessages(prev => [...prev, { role: 'user', text: q }]);
    const a = replyTo(q);
    setTimeout(() => {
      setMessages(prev => [...prev, { role: 'bot', text: a }]);
    }, 450);
    setInput('');
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-5 right-5 btn btn-primary shadow-lg"
        aria-label="Open demo chatbot"
      >
        Demo bot
      </button>

      {open && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4">
          <div className="w-full max-w-md rounded-2xl border border-gray-700 bg-neutral-900">
            <div className="flex items-center justify-between border-b border-gray-800 p-3">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 animate-pulse rounded-full bg-cyan-400" />
                <span className="font-medium">BenZolutions • Demo</span>
              </div>
              <button onClick={() => setOpen(false)} className="text-gray-300 hover:text-white" aria-label="Sluiten">×</button>
            </div>
            <div className="max-h-[60vh] space-y-3 overflow-y-auto p-4">
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${m.role === 'user' ? 'bg-cyan-500 text-black' : 'bg-neutral-800 text-gray-100 border border-gray-700'}`}>
                    {m.text}
                  </div>
                </div>
              ))}
              <div ref={endRef} />
            </div>
            <div className="flex gap-2 border-t border-gray-800 p-3">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') send(); }}
                placeholder="Typ je bericht... (NL/EN)"
                className="flex-1 rounded-xl border border-gray-700 bg-neutral-900 px-3 py-2 outline-none focus:border-cyan-400"
              />
              <button onClick={send} className="btn btn-primary">Stuur</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

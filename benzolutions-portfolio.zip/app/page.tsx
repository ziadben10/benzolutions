'use client';

import Image from "next/image";
import { useState, useMemo } from "react";
import LanguageToggle from "@/components/LanguageToggle";
import ChatbotDemo from "@/components/ChatbotDemo";

type Lang = 'nl' | 'en';

const dict = {
  nl: {
    heroTitle: "AI chatbots & automatisering voor ondernemers",
    heroSub: "Ik bouw praktische AI-oplossingen met Zoho Creator en GPT — simpel, snel, zonder poespas.",
    ctaDemo: "Bekijk demo",
    ctaContact: "Contact",
    whatIDo: "Wat ik doe",
    s1: "Website & WhatsApp chatbots (lead intake, FAQ, afspraken)",
    s2: "Zoho Creator workflows (formulieren, automatisering, CRM)",
    s3: "AI-ondersteunde e-mail & offerte generatie",
    s4: "Dashboarding en kleine tools op maat",
    demos: "Demo's",
    demoBot: "AI Chatbot (demo)",
    demoZoho: "Zoho intake formulier (mock)",
    demoNote: "Dit zijn demo’s om mogelijkheden te tonen — geen klantdata.",
    about: "Over BenZolutions",
    aboutText: "Low-key, resultaatgericht. Geen theater: ik bouw werkende oplossingen. Focus op snelheid, duidelijkheid en onderhoudbaarheid.",
    contact: "Contact",
    contactText: "Klaar om iets te bouwen of testen? Stuur een bericht.",
    waBtn: "WhatsApp openen",
    mailBtn: "Stuur e-mail",
    footer: "© BenZolutions. Alle rechten voorbehouden."
  },
  en: {
    heroTitle: "AI chatbots & automation for small business",
    heroSub: "Practical AI using Zoho Creator and GPT — simple, fast, no fuss.",
    ctaDemo: "View demo",
    ctaContact: "Contact",
    whatIDo: "What I do",
    s1: "Website & WhatsApp chatbots (lead intake, FAQ, bookings)",
    s2: "Zoho Creator workflows (forms, automation, CRM)",
    s3: "AI-assisted email & quote generation",
    s4: "Lightweight dashboards and custom tools",
    demos: "Demos",
    demoBot: "AI Chatbot (demo)",
    demoZoho: "Zoho intake form (mock)",
    demoNote: "These are demos to showcase capabilities — no client data.",
    about: "About BenZolutions",
    aboutText: "Low-key and result-driven. No theatre: I ship working solutions. Focus on speed, clarity and maintainability.",
    contact: "Contact",
    contactText: "Ready to build or test something? Send a message.",
    waBtn: "Open WhatsApp",
    mailBtn: "Send e-mail",
    footer: "© BenZolutions. All rights reserved."
  }
} as const;

export default function Page() {
  const [lang, setLang] = useState<Lang>('nl');
  const t = useMemo(() => dict[lang], [lang]);

  return (
    <main>
      {/* HERO */}
      <section id="home" className="section">
        <div className="container-nice">
          <div className="flex items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <Image src="/logo.svg" alt="BenZolutions" width={160} height={36} priority />
              <span className="hidden sm:inline badge">AI • Zoho • Automatisering</span>
            </div>
            <LanguageToggle onChange={setLang} />
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-2 md:items-center">
            <div>
              <h1 className="text-3xl font-bold md:text-5xl">{t.heroTitle}</h1>
              <p className="mt-4 text-gray-300 md:text-lg">{t.heroSub}</p>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                <a href="#demos" className="btn btn-primary">{t.ctaDemo}</a>
                <a href="#contact" className="btn btn-outline">{t.ctaContact}</a>
              </div>
              <div className="mt-6 flex flex-wrap gap-2 text-sm text-gray-400">
                <span className="badge">Next.js</span>
                <span className="badge">Tailwind</span>
                <span className="badge">Zoho Creator</span>
                <span className="badge">OpenAI</span>
              </div>
            </div>
            <div className="card">
              <p className="text-sm text-gray-400">Demo preview</p>
              <ul className="mt-3 list-disc space-y-1 pl-5 text-gray-200">
                <li>{t.s1}</li>
                <li>{t.s2}</li>
                <li>{t.s3}</li>
                <li>{t.s4}</li>
              </ul>
              <div className="hr" />
              <p className="text-sm text-gray-400">
                Tip: Vervang de demo later door een echte embed (Chatbase / Zoho SalesIQ).
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* WHAT I DO */}
      <section id="services" className="section bg-neutral-950">
        <div className="container-nice">
          <h2 className="text-2xl font-semibold md:text-3xl">{t.whatIDo}</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <div className="card"><span className="text-cyan-400">01</span> — {t.s1}</div>
            <div className="card"><span className="text-cyan-400">02</span> — {t.s2}</div>
            <div className="card"><span className="text-cyan-400">03</span> — {t.s3}</div>
            <div className="card"><span className="text-cyan-400">04</span> — {t.s4}</div>
          </div>
        </div>
      </section>

      {/* DEMOS */}
      <section id="demos" className="section">
        <div className="container-nice">
          <h2 className="text-2xl font-semibold md:text-3xl">{t.demos}</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            <div className="card">
              <h3 className="font-medium">{t.demoBot}</h3>
              <p className="mt-2 text-sm text-gray-400">Open de demo bot rechtsonder en stel een vraag.</p>
              <p className="mt-2 text-xs text-gray-500">{t.demoNote}</p>
            </div>
            <div className="card">
              <h3 className="font-medium">{t.demoZoho}</h3>
              <p className="mt-2 text-sm text-gray-400">
                Vervang dit later door een echt formulier uit Zoho Creator of SalesIQ embed.
              </p>
              <div className="mt-4 grid gap-2">
                <label className="text-sm text-gray-300">Naam</label>
                <input className="rounded-xl border border-gray-700 bg-neutral-900 px-3 py-2" placeholder="Voorbeeldnaam" />
                <label className="text-sm text-gray-300">Vraag</label>
                <textarea className="rounded-xl border border-gray-700 bg-neutral-900 px-3 py-2" placeholder="Vertel kort je use-case..." rows={4} />
                <button className="btn btn-primary mt-2" disabled>Verzenden (mock)</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <section id="about" className="section bg-neutral-950">
        <div className="container-nice">
          <h2 className="text-2xl font-semibold md:text-3xl">{t.about}</h2>
          <p className="mt-3 max-w-3xl text-gray-300">{t.aboutText}</p>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="section">
        <div className="container-nice">
          <h2 className="text-2xl font-semibold md:text-3xl">{t.contact}</h2>
          <p className="mt-3 text-gray-300">{t.contactText}</p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <a
              className="btn btn-primary"
              href="https://wa.me/31600000000?text=Hi%20BenZolutions%2C%20ik%20heb%20interesse%20in%20AI%20chatbots%20%2F%20automatisering."
              target="_blank"
              rel="noreferrer noopener"
            >
              {t.waBtn}
            </a>
            <a
              className="btn btn-outline"
              href="mailto:contact@benzolutions.nl?subject=BenZolutions%20—%20intake"
            >
              {t.mailBtn}
            </a>
          </div>
          <p className="mt-3 text-xs text-gray-500">
            Tip: vervang het WhatsApp-nummer en e-mail met jouw gegevens.
          </p>
        </div>
      </section>

      <footer className="section py-10 bg-neutral-950">
        <div className="container-nice text-center text-sm text-gray-400">{t.footer}</div>
      </footer>

      {/* Floating demo bot */}
      <ChatbotDemo />
    </main>
  );
}

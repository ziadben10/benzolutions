import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "BenZolutions — AI chatbots & automatisering",
  description: "Portfolio van BenZolutions: AI chatbots, Zoho Creator automatisering en slimme intake flows. NL/EN.",
  metadataBase: new URL("https://benzolutions.nl"),
  openGraph: {
    title: "BenZolutions — AI chatbots & automatisering",
    description: "AI chatbots, Zoho Creator automatisering en slimme intake flows.",
    url: "https://benzolutions.nl",
    siteName: "BenZolutions",
    images: [{ url: "/logo.svg", width: 1200, height: 630 }],
    locale: "nl_NL",
    type: "website",
  },
  icons: { icon: "/logo.svg" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="nl">
      <body>{children}</body>
    </html>
  );
}
